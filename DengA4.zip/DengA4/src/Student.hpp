/*
 * Student2.h
 *
 *  Created on: Feb 5, 2020
 *      Author: student
 */

#ifndef STUDENT2_H_
#define STUDENT2_H_

#include <iostream>
using namespace std;

struct Student {
public:

	string studentName;
	int studentID;

};



#endif /* STUDENT2_H_ */
