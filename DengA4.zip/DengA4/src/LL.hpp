/*
 * LL.h
 *
 *  Created on: Feb 5, 2020
 *      Author: student
 */

#ifndef LL_HPP_
#define LL_HPP_
#include <iostream>

#include "Student.hpp"
using namespace std;

template <typename X>
struct LLnode
{

	LLnode * fwdPtr = nullptr;
	X theData;

};

template <typename X>
class LL {
private:

	LLnode <X>  * header;
	LLnode <X>  * tempHeader;

public:

	LL()
	{
		header = nullptr;
		tempHeader = nullptr;
	}
	int list_length();
	int counterLength(int);
	void display_list();
	void counterDisplay(int);
	bool search_list(int);
	void push_front(X);
	void push_back(X);
	Student retrieve_front();
	Student retrieve_back();
	bool delete_node(int);
	void destroy_list();


};

template <typename X>
int LL<X>::list_length()
{
	int length = 0;

	counterLength(length);

	return length;
}

template <typename X>
int LL<X>::counterLength(int i)
{

	if(tempHeader != nullptr)
	{
		i++;
		tempHeader = tempHeader->fwdPtr;
		counterLength(i);
	}

	tempHeader = header;
	return i;

}

template <typename X>
void LL<X>::display_list()
{

	int i = 0;
	if(header == nullptr)
	{
		cout << "Empty List\n";
	}
	else
	{
		counterDisplay(i);
	}
}

template <typename X>
void LL<X>::counterDisplay(int i)
{

	if(tempHeader != nullptr)
	{
		i++;
		cout << "Node " << i << " data -> " << tempHeader->theData.studentName<< " "
				<< tempHeader->theData.studentID << endl;
		tempHeader = tempHeader->fwdPtr;
		counterDisplay(i);
	}

	tempHeader = header;

}

template <typename X>
bool LL<X>::search_list(int ID)
{
	LLnode <X> * temp = header;

	if(header==nullptr)
	{
		cout << "Empty List\n";
	}
	else
	{

		if(tempHeader != nullptr)
		{
			if(temp->theData.studentID == ID)
			{
				return true;
			}

			else
			{
				tempHeader = tempHeader->fwdPtr;
				search_list(ID);

			}

		}

	}

	return false;
}

template <typename X>
void LL<X>::push_front(X nu)
{
	LLnode <X> * temp = new LLnode <X>;

	if(header == nullptr)
	{
		header = temp;
		header->theData = nu ;
	}
	else
	{
		temp->theData = nu;
		temp->fwdPtr = header;
		header = temp;
	}

	tempHeader = header;
}

template <typename X>
void LL<X>::push_back(X nu)
{

	if(header == nullptr)
	{
		LLnode <X> * temp = new LLnode <X>;

		header = temp;
		header->theData = nu;
	}

	if(tempHeader->fwdPtr != nullptr)
	{
		tempHeader = tempHeader->fwdPtr;
		push_back(nu);
	}
	else
	{
		tempHeader->fwdPtr = new LLnode<X>;
		tempHeader->fwdPtr->theData = nu;
	}

	tempHeader = header;

}


template <typename X>
Student LL<X>::retrieve_front()
{
	if(header == nullptr)
	{
		cout << "Node does not exist.";
		header = new LLnode <X>;
		return header->theData;
	}
	else
	{
		return header->theData;
	}
}

//RECURSIVE FUNCTION
template <typename X>
Student LL<X>::retrieve_back()
{
	if(header == nullptr)
	{
		cout << "Node does not exist.";
		header = new LLnode <X>;
		return header->theData;
	}
	if(tempHeader->fwdPtr != nullptr)
	{
		tempHeader = tempHeader->fwdPtr;
		retrieve_back();
	}

	LLnode <X> * temp = tempHeader;
	tempHeader = header;

	return temp->theData;
}
template <typename X>
bool LL<X>::delete_node (int ID)
{

	if(header==nullptr)
	{
		cout << "Empty List\n";
	}
	else
	{
		if(tempHeader->fwdPtr->theData.studentID == ID)
		{
			LLnode <X> * temp = new LLnode<X>;
			if(tempHeader->fwdPtr->fwdPtr != nullptr)
			{
				temp = tempHeader->fwdPtr->fwdPtr;
			}
			delete tempHeader->fwdPtr;
			tempHeader->fwdPtr = temp;
		}
		else
		{
			tempHeader = tempHeader->fwdPtr;
			delete_node(ID);
		}
	}
	return false;
}

//RECURSIVE FUNCTION
template <typename X>
void LL<X>::destroy_list ()
{
	LLnode <X> * temp = header;
	if(header == nullptr)
	{
		cout << "Empty List\n";
	}
	else
	{
		header = temp->fwdPtr;
		delete temp;
		destroy_list();
	}
}

#endif /* LL_HPP_ */
